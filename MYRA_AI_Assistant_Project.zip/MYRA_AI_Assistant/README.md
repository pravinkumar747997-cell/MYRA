# MYRA AI Assistant

Features included:
- Hindi + English + Hinglish chat
- Android speech recognition
- Text-to-speech replies using a device voice
- Basic commands: YouTube, web search, time/date, Settings
- GitHub Actions workflow to build a debug APK

For true ChatGPT-like conversation, connect a secure server/API in a later version. Do not place secret API keys directly in the Android app.
