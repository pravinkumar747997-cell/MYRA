package com.myra.assistant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_MIC = 100;
    private static final int REQ_SPEECH = 101;

    private EditText userInput;
    private TextView chatText;
    private ScrollView chatScroll;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userInput = findViewById(R.id.userInput);
        chatText = findViewById(R.id.chatText);
        chatScroll = findViewById(R.id.chatScroll);
        Button send = findViewById(R.id.sendButton);
        Button voice = findViewById(R.id.voiceButton);
        Button stop = findViewById(R.id.stopButton);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                Locale hi = new Locale("hi", "IN");
                if (tts.isLanguageAvailable(hi) >= TextToSpeech.LANG_AVAILABLE) {
                    tts.setLanguage(hi);
                } else {
                    tts.setLanguage(Locale.US);
                }
                tts.setPitch(1.12f);
                tts.setSpeechRate(1.0f);
            }
        });

        send.setOnClickListener(v -> sendCurrentMessage());
        voice.setOnClickListener(v -> startVoice());
        stop.setOnClickListener(v -> {
            if (tts != null) tts.stop();
        });
    }

    private void sendCurrentMessage() {
        String message = userInput.getText().toString().trim();
        if (message.isEmpty()) return;
        userInput.setText("");
        addChat("YOU: " + message);
        handleMessage(message);
    }

    private void startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MYRA...");
        try {
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            Toast.makeText(this, "Speech recognition is not available on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void handleMessage(String message) {
        String m = message.toLowerCase(Locale.ROOT).trim();

        if (m.contains("youtube kholo") || m.equals("open youtube")) {
            openUrl("https://www.youtube.com");
            reply("Opening YouTube.");
            return;
        }

        if (m.startsWith("search ") || m.contains("google search")) {
            String q = m.replace("google search", "").replaceFirst("^search", "").trim();
            if (!q.isEmpty()) {
                openUrl("https://www.google.com/search?q=" + Uri.encode(q));
                reply("Searching for " + q);
                return;
            }
        }

        if (m.contains("time") || m.contains("samay") || m.contains("kitne baje")) {
            String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date());
            reply("Abhi time hai " + time);
            return;
        }

        if (m.contains("date") || m.contains("tarikh") || m.contains("aaj ka din")) {
            String date = DateFormat.getDateInstance(DateFormat.FULL).format(new Date());
            reply("Aaj " + date + " hai.");
            return;
        }

        if (m.contains("settings kholo") || m.equals("open settings")) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
                reply("Opening phone settings.");
            } catch (Exception e) {
                reply("I could not open settings on this device.");
            }
            return;
        }

        if (m.contains("hello") || m.contains("hi") || m.contains("namaste")) {
            reply("Hello! Main MYRA hoon. How can I help you today?");
            return;
        }

        if (m.contains("kaise ho") || m.contains("how are you")) {
            reply("Main theek hoon, thank you! Main aapki madad ke liye ready hoon.");
            return;
        }

        reply("I understood: " + message + ". Main abhi demo mode mein hoon. Real human-like AI responses ke liye online AI API connection next step mein add ki ja sakti hai.");
    }

    private void reply(String text) {
        addChat("MYRA: " + text);
        if (tts != null) {
            Locale hi = new Locale("hi", "IN");
            if (containsHindi(text) && tts.isLanguageAvailable(hi) >= TextToSpeech.LANG_AVAILABLE) {
                tts.setLanguage(hi);
            } else {
                tts.setLanguage(Locale.US);
            }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MYRA_REPLY");
        }
    }

    private boolean containsHindi(String s) {
        for (char c : s.toCharArray()) {
            if (c >= '\u0900' && c <= '\u097F') return true;
        }
        return false;
    }

    private void addChat(String line) {
        chatText.append("\n\n" + line);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No browser available.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spoken = results.get(0);
                addChat("YOU: " + spoken);
                handleMessage(spoken);
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
